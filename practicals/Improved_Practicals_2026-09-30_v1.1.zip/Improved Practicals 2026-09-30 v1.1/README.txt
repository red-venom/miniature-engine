IMPROVED KS5 PRACTICALS v1.1 — 30 September 2026

START HERE.html is the main index. It opens the lesson guide, the three masters, the red-team review and all 47 paired student and teacher resources.

Inventory (checked by verify_practicals.py on every build):
  Activity resources: 94 files (47 student + 47 teacher)
  Source copies: 102 files for 102 register rows
  Masters: lesson guide, answers, technician preparation, red-team review
  Sheets written in v1.1: 12, 17, 19, 20, 25, 26, 27, 28, 36, 38, 40, 41, 42, 43, 44, 45, 46

Activity resources: numbered sheets for teaching and preparation. Every activity has a Student and a Teacher sheet.
Source copies: separately named replacements for the 102 original files; the source register maps each one to its numbered activity. Where one original file stood for two activities (19 and 20) the copy contains both sheets. Legacy file names are kept on purpose so existing references still resolve; the content is the improved activity named inside.
Source register: paths are relative to the department folder '…/02 - Resources/06 - KS5 - Chemistry/'. The absolute OneDrive prefix present in v1.0 was removed because it identified the author.
Answers master: answers and expected results for the revised questions in this set.
Technician preparation master: summary table, then quantities, controls, trial notes and expected results for every activity.
Red team review: findings on v1.0 and the action taken in v1.1; 'Changes v1.0 to v1.1.csv' is the same list as data.
Implemented changes.csv: v1.0 change, v1.1 change and intended focus for every activity.

Units: volumes and concentrations use cm³ and mol dm⁻³ to match AQA examinations.

Shared methods: Activities 22 and 23 share the cobalt temperature demonstration; 27 and 28 share cracking; 31 and 35 share cyclohexene; 26 and 47 share the prepared-bromine test. Entry 17 (combustion) and entry 18 (neutralisation) are now distinct calorimetry practicals. Plan each shared activity once unless deliberate repetition has a new purpose.

Sheets written in v1.1 for activities that had none in v1.0 (12, 19, 20, 25, 26, 27, 28, 36, 38, 40, 41, 42, 43, 44, 45, 46) and the restored combustion practical (17) have had document review only.

All originals remain unchanged. These files have undergone document and chemistry review, not physical trials. Teachers and technicians should trial live procedures with the actual equipment and reagents and apply current departmental risk assessments before student use. Model and reference-data activities are labelled and do not substitute for hands-on required-practical competence evidence.
